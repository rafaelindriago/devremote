<div class="container">
    <div class="row justify-content-center">
        <div class="col">
            <div class="card">
                <h5 class="card-header">
                    <span class="fas fa-fw fa-tachometer"></span>
                    {{ __('Dashboard') }}
                </h5>

                <div class="card-body">
                    {{ __('You are logged in!') }}
                </div>
            </div>
        </div>
    </div>
</div>
