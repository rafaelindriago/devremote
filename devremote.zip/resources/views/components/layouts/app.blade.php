@extends('layouts.app')

@section('content')
    {{ $slot }}
@endsection
