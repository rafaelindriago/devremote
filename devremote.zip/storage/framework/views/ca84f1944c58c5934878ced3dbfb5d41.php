<div class="card">
    <h5 class="card-header">
        <span class="fas fa-fw fa-book"></span>
        <?php echo e(__("Skills")); ?>

    </h5>

    <div class="card-body">
        <form method="POST"
              wire:submit="saveAll">
            <div class="mb-3">
                <button class="btn btn-primary"
                        data-bs-toggle="modal"
                        data-bs-target="#skills-skill-form"
                        type="button"
                        <?php if(count($skills) >= 8): echo 'disabled'; endif; ?>>
                    <span class="fas fa-fw fa-pen"></span>
                    <?php echo e(__("Add")); ?>

                </button>
            </div>

            <?php if(empty($skills)): ?>
                <div class="alert alert-info"
                     role="alert">
                    <span class="fas fa-fw fa-info-circle"></span>
                    <?php echo e(__("Complete your profile by adding your skills here.")); ?>

                </div>
            <?php endif; ?>

            <?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skillKey => $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card mb-3"
                     wire:key="skill-<?php echo e($skillKey); ?>">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6 col-lg-3">
                                <div class="mb-3">
                                    <label class="form-label"
                                           for="language-<?php echo e($skillKey); ?>">
                                        <?php echo e(__("Language")); ?>

                                    </label>

                                    <div class="form-control <?php $__errorArgs = ["skills.{$skillKey}.languageKey"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                         id="language-<?php echo e($skillKey); ?>"
                                         tabindex="0"
                                         contenteditable="false">
                                        <span class="<?php echo e($skill["languageIcon"]); ?>"></span>
                                        <?php echo e($skill["languageName"]); ?>

                                    </div>

                                    <?php $__errorArgs = ["skills.{$skillKey}.languageKey"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"
                                             role="alert">
                                            <strong>
                                                <span class="fas fa-fw fa-exclamation-circle"></span>
                                                <?php echo e($message); ?>

                                            </strong>
                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-6 col-lg-3">
                                <div class="mb-3">
                                    <label class="form-label"
                                           for="level-<?php echo e($skillKey); ?>">
                                        <?php echo e(__("Level")); ?>

                                    </label>

                                    <input class="form-control <?php $__errorArgs = ["skills.{$skillKey}.level"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           id="level-<?php echo e($skillKey); ?>"
                                           type="text"
                                           readonly
                                           wire:model="skills.<?php echo e($skillKey); ?>.levelTranslated">

                                    <?php $__errorArgs = ["skills.{$skillKey}.level"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"
                                             role="alert">
                                            <strong>
                                                <span class="fas fa-fw fa-exclamation-circle"></span>
                                                <?php echo e($message); ?>

                                            </strong>
                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label class="form-label"
                                           for="description-<?php echo e($skillKey); ?>">
                                        <?php echo e(__("Description")); ?>

                                    </label>

                                    <textarea class="form-control <?php $__errorArgs = ["skills.{$skillKey}.description"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                              id="description-<?php echo e($skillKey); ?>"
                                              readonly
                                              wire:model="skills.<?php echo e($skillKey); ?>.description"></textarea>

                                    <?php $__errorArgs = ["skills.{$skillKey}.description"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"
                                             role="alert">
                                            <strong>
                                                <span class="fas fa-fw fa-exclamation-circle"></span>
                                                <?php echo e($message); ?>

                                            </strong>
                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        <button class="btn btn-primary"
                                type="button"
                                wire:click="edit(<?php echo e($skillKey); ?>)"
                                wire:loading.attr="disabled"
                                wire:target="edit(<?php echo e($skillKey); ?>)">
                            <span class="fas fa-fw fa-edit"
                                  wire:loading.remove
                                  wire:target="edit(<?php echo e($skillKey); ?>)"></span>
                            <span class="fas fa-fw fa-circle-notch fa-spin"
                                  wire:loading
                                  wire:target="edit(<?php echo e($skillKey); ?>)"></span>
                            <?php echo e(__("Edit")); ?>

                        </button>

                        <button class="btn btn-danger"
                                data-key="<?php echo e($skillKey); ?>"
                                data-bs-toggle="modal"
                                data-bs-target="#skill-delete-confirmation"
                                type="button"
                                aria-label="<?php echo e(__("Delete")); ?>">
                            <span class="fas fa-fw fa-trash"></span>
                        </button>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div class="row">
                <div class="col">
                    <div class="mb-0">
                        <button class="btn btn-primary"
                                type="submit">
                            <span class="fas fa-fw fa-save"
                                  wire:loading.remove
                                  wire:target="saveAll"></span>
                            <span class="fas fa-fw fa-circle-notch fa-spin"
                                  wire:loading
                                  wire:target="saveAll"></span>
                            <?php echo e(__("Save")); ?>

                        </button>

                        <button class="btn btn-secondary"
                                type="button"
                                aria-label="<?php echo e(__("Reset")); ?>"
                                wire:click="resetFormAll"
                                wire:loading.attr="disabled"
                                wire:target="resetFormAll">
                            <span class="fas fa-fw fa-undo-alt"
                                  wire:loading.remove
                                  wire:target="resetFormAll"></span>
                            <span class="fas fa-fw fa-circle-notch fa-spin"
                                  wire:loading
                                  wire:target="resetFormAll"></span>
                        </button>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <div class="modal fade"
         id="skills-skill-form"
         aria-labelledby="skills-skill-form-title"
         tabindex="-1"
         wire:ignore.self
         x-data="{ modal: Modal.getOrCreateInstance($root) }"
         x-on:livewire-skills-skill-editing.window="modal.show()"
         x-on:livewire-skills-skill-edited.window="modal.hide()"
         x-on:shown-bs-modal.dot="$root.querySelector('#language-key').focus()"
         x-on:hidden-bs-modal.dot="$wire.call('resetForm', true)">

        <div class="modal-dialog modal-xl modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"
                        id="skills-skill-form-title">
                        <span class="fas fa-fw fa-book"></span>
                        <?php echo e(__("Add Skill")); ?>

                    </h5>

                    <button class="btn-close"
                            data-bs-dismiss="modal"
                            type="button"
                            aria-label="<?php echo e(__("Close")); ?>"
                            wire:loading.attr="disabled"
                            wire:target="save,resetForm"></button>
                </div>

                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6 col-lg-3">
                            <div class="mb-3">
                                <label class="form-label"
                                       for="language-key">
                                    <?php echo e(__("Language")); ?>

                                </label>

                                <div class="dropdown"
                                     x-data="{
                                         value: $wire.entangle('languageKey'),
                                         selectedIndex: -1,
                                         filter: '',
                                         options: <?php echo \Illuminate\Support\Js::from($languages)->toHtml() ?>,
                                         get filteredOptions() {
                                             if ($data.filter.length >= 1) {
                                                 return $data.options.filter((option) => {
                                                     return option.name.toLowerCase()
                                                         .indexOf($data.filter.toLowerCase().trim()) >= 0
                                                 })
                                             } else { return [] }
                                         },
                                         init() {
                                             $watch('value', () => $data.selectByValue())
                                             $data.selectByValue()
                                         },
                                         selectByValue() {
                                             if ($data.value.length == 0) { $data.selectedIndex = -1 } else {
                                                 for (const index in $data.options) {
                                                     if ($data.options[index].id == $data.value) {
                                                         $data.selectedIndex = index
                                                         break
                                                     }
                                                 }
                                             }
                                         },
                                         focusToFirst() {
                                             const first = $root.querySelector('.dropdown-item')
                                             if (first) { first.focus() }
                                         }
                                     }"
                                     x-on:shown-bs-dropdown.dot="$refs.filter.focus()"
                                     x-on:hidden-bs-dropdown.dot="$refs.input.focus()">

                                    <button class="form-select text-start <?php $__errorArgs = ["languageKey"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            id="language-key"
                                            data-bs-toggle="dropdown"
                                            type="button"
                                            <?php if($key): echo 'disabled'; endif; ?>
                                            x-ref="input">
                                        <span class="text-muted"
                                              x-show="selectedIndex == -1">
                                            <?php echo e(__("Choose an Option")); ?>

                                        </span>

                                        <span x-show="selectedIndex >= 0">
                                            <span style="font-size: 16px;"
                                                  x-bind:class="selectedIndex >= 0 && options[selectedIndex].class"></span>
                                            <span x-text="selectedIndex >= 0 && options[selectedIndex].name"></span>
                                        </span>
                                    </button>

                                    <?php $__errorArgs = ["languageKey"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"
                                             role="alert">
                                            <strong>
                                                <span class="fas fa-fw fa-exclamation-circle"></span>
                                                <?php echo e($message); ?>

                                            </strong>
                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    <ul class="dropdown-menu w-100 overflow-y-scroll"
                                        style="max-height: 250px;">
                                        <li>
                                            <div class="dropdown-header">
                                                <input class="form-control form-control-sm"
                                                       type="text"
                                                       maxlength="128"
                                                       placeholder="<?php echo e(__("Type to Filter Options")); ?>"
                                                       x-ref="filter"
                                                       x-model="filter"
                                                       x-on:focusin="$event.target.select()"
                                                       x-on:keydown.down.prevent="focusToFirst()">
                                            </div>
                                        </li>

                                        <li>
                                            <hr class="dropdown-divider">
                                        </li>

                                        <li>
                                            <a class="dropdown-item text-muted"
                                               href="#"
                                               x-on:click.prevent="value = ''">
                                                <?php echo e(__("None")); ?>

                                            </a>
                                        </li>

                                        <template x-for="(option, index) in filteredOptions">
                                            <li>
                                                <a class="dropdown-item"
                                                   href="#"
                                                   x-bind:class="{ 'active': value == option.id }"
                                                   x-on:click.prevent="value = option.id">
                                                    <span style="font-size: 16px;"
                                                          x-bind:class="option.class"></span>
                                                    <span x-text="option.name"></span>
                                                </a>
                                            </li>
                                        </template>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-6 col-lg-3">
                            <div class="mb-3">
                                <label class="form-label">
                                    <?php echo e(__("Level")); ?>

                                </label>

                                <?php $__currentLoopData = ["Beginner", "Intermediate", "Expert"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $level): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="form-check">
                                        <input class="form-check-input <?php $__errorArgs = ["level"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                               id="level-<?php echo e(strtolower($level)); ?>"
                                               type="radio"
                                               value="<?php echo e($level); ?>"
                                               wire:model="level">
                                        <label class="form-check-label"
                                               for="level-<?php echo e(strtolower($level)); ?>">
                                            <?php echo e(__($level)); ?>

                                        </label>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>

                        <div class="col-lg-6">
                            <div class="mb-3">
                                <label class="form-label"
                                       for="description">
                                    <?php echo e(__("Description")); ?>

                                </label>

                                <textarea class="form-control <?php $__errorArgs = ["description"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                          id="description"
                                          maxlength="256"
                                          wire:model="description"></textarea>

                                <?php $__errorArgs = ["description"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"
                                         role="alert">
                                        <strong>
                                            <span class="fas fa-fw fa-exclamation-circle"></span>
                                            <?php echo e($message); ?>

                                        </strong>
                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="modal-footer">
                    <button class="btn btn-primary"
                            type="button"
                            wire:click="save"
                            wire:loading.attr="disabled"
                            wire:target="save">
                        <span class="fas fa-fw fa-save"
                              wire:loading.remove
                              wire:target="save"></span>
                        <span class="fas fa-fw fa-circle-notch fa-spin"
                              wire:loading
                              wire:target="save"></span>
                        <?php echo e(__("Save")); ?>

                    </button>

                    <button class="btn btn-secondary"
                            type="button"
                            aria-label="<?php echo e(__("Reset")); ?>"
                            wire:click="resetForm"
                            wire:loading.attr="disabled"
                            wire:target="resetForm">
                        <span class="fas fa-fw fa-undo-alt"
                              wire:loading.remove
                              wire:target="resetForm"></span>
                        <span class="fas fa-fw fa-circle-notch fa-spin"
                              wire:loading
                              wire:target="resetForm"></span>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade"
         id="skill-delete-confirmation"
         tabindex="-1"
         wire:ignore.self
         x-data="{ modal: Modal.getOrCreateInstance($root), key: null }"
         x-on:show-bs-modal.dot="key = $event.relatedTarget.dataset.key"
         x-on:hide-bs-modal.dot="key = null"
         x-on:livewire-skills-skill-removed.window="modal.hide()">

        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <span class="fas fa-fw fa-trash"></span>
                        <?php echo e(__("Delete Skill")); ?>

                    </h5>

                    <button class="btn-close"
                            data-bs-dismiss="modal"
                            type="button"
                            aria-label="<?php echo e(__("Close")); ?>"
                            wire:loading.attr="disabled"
                            wire:target="delete"></button>
                </div>

                <div class="modal-body">
                    <strong>
                        <?php echo e(__("Are you sure?")); ?>

                    </strong>
                </div>

                <div class="modal-footer">
                    <button class="btn btn-danger"
                            type="button"
                            wire:loading.attr="disabled"
                            wire:target="delete"
                            x-on:click="$wire.call('delete', key)">
                        <span class="fas fa-fw fa-trash"
                              wire:loading.remove
                              wire:target="delete"></span>
                        <span class="fas fa-fw fa-circle-notch fa-spin"
                              wire:loading
                              wire:target="delete"></span>
                        <?php echo e(__("Delete")); ?>

                    </button>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Rafael\Documents\devremote\resources\views\livewire\resume\skills.blade.php ENDPATH**/ ?>