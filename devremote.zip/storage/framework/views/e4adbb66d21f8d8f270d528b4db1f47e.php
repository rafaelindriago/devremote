<div class="card">
    <h5 class="card-header">
        <span class="fas fa-fw fa-id-card"></span>
        <?php echo e(__("Personal Information")); ?>

    </h5>

    <div class="card-body">
        <form method="POST"
              wire:submit="save">

            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label class="form-label"
                               for="name"><?php echo e(__("Name")); ?></label>

                        <input class="form-control <?php $__errorArgs = ["name"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               id="name"
                               type="text"
                               maxlength="50"
                               placeholder="<?php echo e(__("John")); ?>"
                               autofocus
                               wire:model="name">

                        <?php $__errorArgs = ["name"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"
                                 role="alert">
                                <strong>
                                    <span class="fas fa-fw fa-exclamation-circle"></span>
                                    <?php echo e($message); ?>

                                </strong>
                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="mb-3">
                        <label class="form-label"
                               for="last-name"><?php echo e(__("Last Name")); ?></label>

                        <input class="form-control <?php $__errorArgs = ["lastName"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               id="last-name"
                               type="text"
                               maxlength="50"
                               placeholder="<?php echo e(__("Doe")); ?>"
                               wire:model="lastName">

                        <?php $__errorArgs = ["lastName"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"
                                 role="alert">
                                <strong>
                                    <span class="fas fa-fw fa-exclamation-circle"></span>
                                    <?php echo e($message); ?>

                                </strong>
                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6 col-xl-4">
                    <div class="mb-3">
                        <label class="form-label"
                               for="birth-at"><?php echo e(__("Birth Date")); ?></label>

                        <input class="form-control <?php $__errorArgs = ["birthAt"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               id="birth-at"
                               type="text"
                               maxlength="10"
                               placeholder="<?php echo e(__("DD-MM-YYYY")); ?>"
                               inputmode="numeric"
                               wire:model="birthAt"
                               x-data
                               x-mask="99-99-9999">

                        <?php $__errorArgs = ["birthAt"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"
                                 role="alert">
                                <strong>
                                    <span class="fas fa-fw fa-exclamation-circle"></span>
                                    <?php echo e($message); ?>

                                </strong>
                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label class="form-label"
                               for="email"><?php echo e(__("Email Address")); ?></label>

                        <input class="form-control <?php $__errorArgs = ["email"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               id="email"
                               type="text"
                               maxlength="100"
                               placeholder="<?php echo e(__("example@domain.com")); ?>"
                               wire:model="email">

                        <?php $__errorArgs = ["email"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"
                                 role="alert">
                                <strong>
                                    <span class="fas fa-fw fa-exclamation-circle"></span>
                                    <?php echo e($message); ?>

                                </strong>
                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="col-md-6 col-xl-4">
                    <div class="mb-3">
                        <label class="form-label"
                               for="phone"><?php echo e(__("Phone Number")); ?></label>

                        <input class="form-control <?php $__errorArgs = ["phone"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               id="phone"
                               type="text"
                               maxlength="15"
                               placeholder="+000 0000000000"
                               inputmode="numeric"
                               wire:model="phone"
                               x-data="{
                                   mask(input) {
                                       if (input.length == 1) { return '+' }
                                       for (let count = 1; count <= 3; count++) {
                                           if ((new RegExp(`^\\+[\\d]\{${count}\}[\\s]`)).test(input)) {
                                               return (new String('+')).padEnd(count + 1, '9')
                                                   .concat(' ').padEnd(count + 12, '9')
                                           }
                                       }
                                       return '+999 999999999'
                                   }
                               }"
                               x-mask:dynamic="$data.mask">

                        <?php $__errorArgs = ["phone"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"
                                 role="alert">
                                <strong>
                                    <span class="fas fa-fw fa-exclamation-circle"></span>
                                    <?php echo e($message); ?>

                                </strong>
                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label class="form-label"
                               for="country-code"><?php echo e(__("Country")); ?></label>

                        <div class="dropdown"
                             x-data="{
                                 value: $wire.entangle('countryCode'),
                                 selectedIndex: -1,
                                 options: <?php echo \Illuminate\Support\Js::from($countries)->toHtml() ?>,
                                 init() {
                                     $watch('value', () => $data.selectByValue())
                                     $data.selectByValue()
                                 },
                                 selectByValue() {
                                     if ($data.value.length == 0) { $data.selectedIndex = -1 } else {
                                         for (const index in $data.options) {
                                             if ($data.options[index].code == $data.value) {
                                                 $data.selectedIndex = index
                                                 break
                                             }
                                         }
                                     }
                                 },
                                 focusToActive() {
                                     const active = $root.querySelector('.dropdown-menu .active')
                                     if (active) { active.focus() }
                                 },
                                 selectByKeyboard(initial) {
                                     for (const index in $data.options) {
                                         if ($data.options[index].name.startsWith(initial.toUpperCase())) {
                                             $data.value = $data.options[index].code
                                             $data.selectedIndex = index
                                             $nextTick(() => $data.focusToActive())
                                             break
                                         }
                                     }
                                 }
                             }"
                             x-on:shown-bs-dropdown.dot="focusToActive()"
                             x-on:keydown="selectByKeyboard($event.key)"
                             x-on:hidden-bs-dropdown.dot="$refs.input.focus()">

                            <button class="form-select text-start <?php $__errorArgs = ["countryCode"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    id="country-code"
                                    data-bs-toggle="dropdown"
                                    type="button"
                                    x-ref="input">
                                <span class="text-muted"
                                      x-show="selectedIndex == -1">
                                    <?php echo e(__("Choose an Option")); ?>

                                </span>

                                <template x-if="selectedIndex >= 0">
                                    <span>
                                        <img alt="<?php echo e(__("Flag")); ?>"
                                             width="25"
                                             height="15"
                                             x-bind:src="options[selectedIndex].flag">
                                        <span class="ms-1"
                                              x-text="options[selectedIndex].name"></span>
                                    </span>
                                </template>
                            </button>

                            <?php $__errorArgs = ["countryCode"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"
                                     role="alert">
                                    <strong>
                                        <span class="fas fa-fw fa-exclamation-circle"></span>
                                        <?php echo e($message); ?>

                                    </strong>
                                </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <ul class="dropdown-menu w-100 overflow-y-scroll"
                                style="max-height: 250px;">
                                <li>
                                    <a class="dropdown-item"
                                       href="#"
                                       x-on:click.prevent="value = ''">
                                        <?php echo e(__("None")); ?>

                                    </a>
                                </li>

                                <li>
                                    <hr class="dropdown-divider">
                                </li>

                                <template x-for="(option, index) in options">
                                    <li>
                                        <a class="dropdown-item"
                                           href="#"
                                           x-bind:id="option.code"
                                           x-bind:class="{ 'active': value == option.code }"
                                           x-on:click.prevent="value = option.code">
                                            <img alt="<?php echo e(__("Flag")); ?>"
                                                 width="25"
                                                 height="15"
                                                 x-bind:src="option.flag">
                                            <span class="ms-1"
                                                  x-text="option.name"></span>
                                        </a>
                                    </li>
                                </template>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div class="mb-0">
                <button class="btn btn-primary"
                        type="submit">
                    <span class="fas fa-fw fa-save"
                          wire:loading.remove
                          wire:target="save"></span>
                    <span class="fas fa-fw fa-circle-notch fa-spin"
                          wire:loading
                          wire:target="save"></span>
                    <?php echo e(__("Save")); ?>

                </button>

                <button class="btn btn-secondary"
                        type="button"
                        aria-label="<?php echo e(__("Reset")); ?>"
                        wire:click="resetForm"
                        wire:loading.attr="disabled"
                        wire:target="resetForm">
                    <span class="fas fa-fw fa-undo-alt"
                          wire:loading.remove
                          wire:target="resetForm"></span>
                    <span class="fas fa-fw fa-circle-notch fa-spin"
                          wire:loading
                          wire:target="resetForm"></span>
                </button>
            </div>
        </form>
    </div>
</div>
<?php /**PATH C:\Users\Rafael\Documents\devremote\resources\views\livewire\resume\personal-information.blade.php ENDPATH**/ ?>