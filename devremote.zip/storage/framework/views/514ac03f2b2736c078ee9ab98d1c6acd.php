<div class="container">
    <div class="row justify-content-center">
        <div class="col">
            <div class="card">
                <h5 class="card-header">
                    <span class="fas fa-fw fa-tachometer"></span>
                    <?php echo e(__('Dashboard')); ?>

                </h5>

                <div class="card-body">
                    <?php echo e(__('You are logged in!')); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Rafael\Documents\devremote\resources\views\livewire\home.blade.php ENDPATH**/ ?>