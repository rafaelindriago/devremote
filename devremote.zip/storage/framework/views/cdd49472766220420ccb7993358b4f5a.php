<div class="container">
    <div class="row justify-content-center">
        <div class="col">
            <div class="card">
                <h5 class="card-header">
                    <span class="fas fa-fw fa-file-alt"></span>
                    <?php echo e(__('Resume')); ?>

                </h5>

                <div class="card-body">
                    <div class="row">
                        <div class="col-12 col-md-8 col-xl-4 mx-auto mx-xl-0 mb-3">
                            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('resume.photo', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-705194842-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                        </div>

                        <div class="col-12 col-xl-8 mx-auto mx-xl-0 mb-3">
                            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('resume.personal-information', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-705194842-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                        </div>

                        <div class="col">
                            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('resume.skills', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-705194842-2', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Rafael\Documents\devremote\resources\views\livewire\resume.blade.php ENDPATH**/ ?>