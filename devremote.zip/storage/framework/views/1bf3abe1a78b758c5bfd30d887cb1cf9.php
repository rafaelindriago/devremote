<img class="rounded-circle shadow-sm me-1"
     src="<?php echo e(URL::route("user.image")); ?>?ts=<?php echo e(Auth::user()->updated_at->timestamp); ?>"
     alt="<?php echo e(Auth::user()->name); ?>"
     height="40">
<?php /**PATH C:\Users\Rafael\Documents\devremote\resources\views\livewire\components\avatar.blade.php ENDPATH**/ ?>