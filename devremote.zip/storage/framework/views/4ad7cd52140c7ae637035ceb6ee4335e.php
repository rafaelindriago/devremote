<div class="container d-flex justify-content-center justify-content-md-end w-100"
     x-on:hide-bs-toast.dot="$wire.call('dismiss', $event.target.dataset.key)">

    <div class="toast-container position-fixed bottom-0 mb-3"
         <?php if(count($toasts) > 0): ?> wire:poll.5000ms <?php endif; ?>>

        <?php $__currentLoopData = $toasts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $toast): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="toast"
                 data-key="<?php echo e($key); ?>"
                 role="alert"
                 aria-live="assertive"
                 aria-atomic="true"
                 wire:ignore.self
                 wire:key="toast-<?php echo e($key); ?>">

                <div class="toast-header">
                    <strong class="me-auto">
                        <?php switch(data_get($toast, 'type')):
                            case ("success"): ?>
                                <span class="fas fa-fw fa-check-circle text-success"></span>
                                <?php echo e(__("Success")); ?>

                            <?php break; ?>

                            <?php case ("error"): ?>
                                <span class="fas fa-fw fa-times-circle text-danger"></span>
                                <?php echo e(__("Error")); ?>

                            <?php break; ?>

                            <?php case ("warning"): ?>
                                <span class="fas fa-fw fa-exclamation-circle text-warning"></span>
                                <?php echo e(__("Warning")); ?>

                            <?php break; ?>

                            <?php case ("info"): ?>
                                <span class="fas fa-fw fa-info-circle text-info"></span>
                                <?php echo e(__("Notice")); ?>

                            <?php break; ?>

                            <?php default: ?>
                                <span class="fas fa-fw fa-info-circle text-info"></span>
                                <?php echo e(__("Notice")); ?>

                            <?php break; ?>
                        <?php endswitch; ?>
                    </strong>

                    <small class="text-body-secondary">
                        <?php echo e($diffForHumans(data_get($toast, "timestamp"))); ?>

                    </small>

                    <button class="btn-close"
                            data-bs-dismiss="toast"
                            type="button"
                            aria-label="<?php echo e(__("Close")); ?>"></button>
                </div>

                <div class="toast-body">
                    <?php echo e(data_get($toast, "message")); ?>

                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

    <?php
        $__scriptKey = '2491198514-0';
        ob_start();
    ?>
    <script>
        Livewire.hook('morph.added', ({
            el
        }) => {
            if (el.classList.contains('toast')) {
                Toast.getOrCreateInstance(el, {
                        delay: 60000
                    })
                    .show()
            }
        })
    </script>
    <?php
        $__output = ob_get_clean();

        \Livewire\store($this)->push('scripts', $__output, $__scriptKey)
    ?>
<?php /**PATH C:\Users\Rafael\Documents\devremote\resources\views\livewire\components\toast.blade.php ENDPATH**/ ?>