<!DOCTYPE html>

<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>"
      data-bs-theme="dark">

<head>
    <meta charset="utf-8">
    <meta name="viewport"
          content="width=device-width, initial-scale=1">

    <meta name="csrf-token"
          content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/app.scss']); ?>

    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

</head>

<body>
    <div id="app">
        <nav class="navbar navbar-expand-md shadow-sm">
            <div class="container">
                <a class="navbar-brand"
                   href="<?php echo e(route('home')); ?>"
                   wire:navigate>
                    <span class="fas fa-fw fa-computer"></span>
                    <?php echo e(config('app.name', 'Laravel')); ?>

                </a>
                <button class="navbar-toggler"
                        type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#navbar-supported-content"
                        aria-controls="navbar-supported-content"
                        aria-expanded="false"
                        aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse"
                     id="navbar-supported-content">
                    <ul class="navbar-nav me-auto">

                    </ul>

                    <ul class="navbar-nav ms-auto">
                        <?php if(auth()->guard()->guest()): ?>
                            <?php if(Route::has('login')): ?>
                                <li class="nav-item">
                                    <a class="nav-link"
                                       href="<?php echo e(route('login')); ?>">
                                        <span class="fas fa-fw fa-sign-in"></span>
                                        <?php echo e(__('Login')); ?>

                                    </a>
                                </li>
                            <?php endif; ?>

                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link"
                                       href="<?php echo e(route('register')); ?>">
                                        <span class="fas fa-fw fa-user-plus"></span>
                                        <?php echo e(__('Register')); ?>

                                    </a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle p-0"
                                   id="navbar-dropdown"
                                   href="#"
                                   role="button"
                                   data-bs-toggle="dropdown"
                                   aria-haspopup="true"
                                   aria-expanded="false"
                                   v-pre>
                                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.avatar', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-2612637679-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                                    <?php echo e(Auth::user()->name); ?>

                                </a>

                                <ul class="dropdown-menu dropdown-menu-end mt-2"
                                    aria-labelledby="navbar-dropdown">
                                    <li>
                                        <a class="dropdown-item"
                                           href="<?php echo e(route('resume')); ?>"
                                           wire:navigate>
                                            <span class="fas fa-fw fa-file-alt"></span>
                                            <?php echo e(__('Resume')); ?>

                                        </a>
                                    </li>

                                    <li>
                                        <hr class="dropdown-divider">
                                    </li>

                                    <li>
                                        <form action="<?php echo e(route('logout')); ?>"
                                              method="POST">
                                            <?php echo csrf_field(); ?>
                                            <div class="d-grid gap-2 px-2">
                                                <button class="btn btn-danger text-nowrap"
                                                        type="submit">
                                                    <span class="fas fa-fw fa-sign-out"></span>
                                                    <?php echo e(__('Logout')); ?>

                                                </button>
                                            </div>
                                        </form>
                                    </li>
                                </ul>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>

            <?php app("livewire")->forceAssetInjection(); ?><div x-persist="<?php echo e('toast'); ?>">
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.toast', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-2612637679-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </div>
        </main>
    </div>

    <script data-navigate-once>
        document.addEventListener('livewire:navigated', () => {
            const autofocus = document.querySelector('[autofocus]')

            if (autofocus) {
                autofocus.focus()
            }
        })
    </script>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.js']); ?>

    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scriptConfig(); ?>


    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html>
<?php /**PATH C:\Users\Rafael\Documents\devremote\resources\views\layouts\app.blade.php ENDPATH**/ ?>